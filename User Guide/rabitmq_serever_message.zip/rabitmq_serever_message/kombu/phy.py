from kombu import Connection, Exchange, Producer, Queue


rabbit_url = "amqp://localhost:5672/"
connection = Connection(rabbit_url)

channel = connection.channel()
exchange = Exchange("example-exchange", type="direct")
producer = Producer(exchange=exchange, channel=channel, routing_key="BOB")
queue = Queue(name="example-queue", exchange=exchange, routing_key="BOB")
queue.maybe_bind(connection)
queue.declare()
producer.publish("Hello there!")
# 
# from __future__ import with_statement
# from queues import task_exchange

# from kombu.common import maybe_declare
# from kombu.pools import producers
# # from pika 


# if __name__ == "__main__":
#     from kombu import BrokerConnection

#     connection = BrokerConnection("amqp://guest:guest@localhost:5672//")

#     with producers[connection].acquire(block=True) as producer:
#         maybe_declare(task_exchange, producer.channel)
        
#         payload = {"type": "handshake", "content": "hello #1"}
#         producer.publish(payload, exchange = 'msgs', serializer="pickle", routing_key = 'message_1')
        
#         payload = {"type": "handshake", "content": "hello #2"}
#         producer.publish(payload, exchange = 'msgs', serializer="pickle", routing_key = 'message_2')
