from kombu import Connection, Exchange, Queue, Consumer

def main():
    rabbit_url = "amqp://localhost:5672/"
    connection = Connection(rabbit_url)

    exchange = Exchange("example-exchange", type="direct")
    queue = Queue(name="example-queue", exchange=exchange, routing_key="BOB")

    def process_message(body, message):
        print("The body is {}".format(body))
        message.ack()

    with Consumer(connection, queues=queue, callbacks=[process_message], accept=["text/plain"]):
        connection.drain_events(timeout=2)


            # print("bye bye")
if __name__ == "__main__":
    main()
