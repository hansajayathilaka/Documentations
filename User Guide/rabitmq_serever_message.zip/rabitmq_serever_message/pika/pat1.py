import pika

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

chanel = connection.channel()

def callback(ch, method, properties, body):
    print ("[x] Recieved %r" % body)

chanel.basic_consume(
    queue = 'pat2',
    on_message_callback = callback,
    auto_ack = True
)

print('[*] waiting for message. to exit press ctrl+c')

chanel.start_consuming()