import pika
import json

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

chanel = connection.channel()

chanel.queue_declare(queue='pat2')

message = {'id': 1, 'name': 'name1'}

chanel.basic_publish(
    exchange='',
    routing_key='pat',
    body= json.dumps(message),
    properties=pika.BasicProperties(
        delivery_mode = 2, # make message persistent
    )
)

chanel.close()