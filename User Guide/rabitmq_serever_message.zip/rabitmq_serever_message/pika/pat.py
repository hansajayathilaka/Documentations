import pika
import json

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host="localhost")
)

chanel = connection.channel()

def callback(ch, method, properties, body):
    print ("[x] Recieved %r" % json.loads(body))

chanel.basic_consume(
    queue = 'pat',
    on_message_callback = callback,
    auto_ack = True
)

print('[*] waiting for message. to exit press ctrl+c')

chanel.start_consuming()